import { useState } from 'react';
import { FaCar } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';
import "./Cotizar.css";

export default function Cotizar() {
  const [showRegister, setShowRegister] = useState(false);
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [fechaNacimiento, setFechaNacimiento] = useState('');
  const [correo, setCorreo] = useState('');

  const apiUrlAuto = "http://localhost:5287/api/Autoes";
  const apiUrlPersona = 'http://localhost:5287/api/Personas';
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const dni = e.target.elements.dni.value;
    const placa = e.target.elements.placa.value;
    
    if (dni === '' || placa === '') {
      setShowRegister(true);
    } else {
      try {
        const response = await fetch(`${apiUrlAuto}?serie=${placa}`);
        const data = await response.json();
        
        console.log("Respuesta de la API:", data);
  
        if (Array.isArray(data) && data.length > 0) {
          navigate('/poliza'); // Redirige a /poliza si la placa existe
        } else {
          setShowRegister(true); // Muestra el formulario de registro si la placa no existe
        }
      } catch (error) {
        console.error("Error al verificar la placa:", error);
        setShowRegister(true); // Muestra el formulario de registro en caso de error
      }
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();
    
    if (!nombre || !apellido || !fechaNacimiento || !correo) {
      alert('Por favor completa todos los campos');
      return;
    }
    
    try {
      const response = await fetch(apiUrlPersona, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre,
          apellido,
          fechaNacimiento,
          email: correo, // Asegúrate de que la clave coincida con el nombre en la tabla
        }),
      });

      if (response.ok) {
        alert('Persona registrada con éxito');
        setShowRegister(false);
        // Opcional: Puedes redirigir al usuario o hacer otras acciones aquí
      } else {
        alert('Error al registrar la persona');
      }
    } catch (error) {
      console.error("Error al registrar la persona:", error);
      alert('Error al registrar la persona');
    }
  };

  return (
    <div className="container-cotizar">
      <img src="/src/assets/bolante.avif" alt="" />
      <div className="cotizar-text">
        <p className="cotizar-parrafo1">Asegura tu vehiculo</p>
        <h1>
          Protegemos tu auto desde<br /> el primer dia
        </h1>
        <form className="form-cotizar" onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="DNI"
            className="input-cotizar"
            id="dni"
          />
          <input
            type="text"
            placeholder="Placa"
            className="input-cotizar"
            id="placa"
          />
          <label>Tipo de Vehiculo</label>
          <p className="cotizar-parrafo2 parrafo-line">
            Al continuar acepto la <a href="#">Politicas de privacidad</a>
          </p>
          <div className="container-check">
            <input type="checkbox" name="" value="Boat" required />
            <label className="cotizar-parrafo2">
              Acepto la Política para el uso y tratamiento de datos personales
              para Promociones Comerciales y otros fines
            </label>
          </div>
          <button className="buton-acceso btn-cotizar" type="submit">
            Cotizar
          </button>
        </form>

        {showRegister && (
          <div className="container-registrer" style={{ display: 'flex' }}>
            <div className="registrar-car">
              <a href="#" onClick={() => setShowRegister(false)}>Cerrar X</a>
              <div className="containt-form-register">
                <FaCar className="car-icon" />
                <h1>Sobre tu vehículo</h1>
                <h1 className="placa">placa</h1>
                <p className='form-parrafo-register'>Registra tus Datos</p>
                <form onSubmit={handleRegisterSubmit} className="form-register-placa">
                  <div className="form-register">
                    <div className="input-register">
                      <label>Nombre</label>
                      <input 
                        type="text" 
                        placeholder="Nombre" 
                        value={nombre} 
                        onChange={(e) => setNombre(e.target.value)} 
                      />
                    </div>
                    <div className="input-register">
                      <label>Apellido</label>
                      <input 
                        type="text" 
                        placeholder="Apellido" 
                        value={apellido} 
                        onChange={(e) => setApellido(e.target.value)} 
                      />
                    </div>
                    <div className="input-register">
                      <label>Fecha Nacimiento</label>
                      <input 
                        type="date" 
                        placeholder="Fecha Nacimiento" 
                        value={fechaNacimiento} 
                        onChange={(e) => setFechaNacimiento(e.target.value)} 
                      />
                    </div>
                  </div>
                  <div className="input-register input-serie">
                    <label>Correo</label>
                    <input 
                      type="email" 
                      placeholder="Ingrese su Correo" 
                      value={correo} 
                      onChange={(e) => setCorreo(e.target.value)} 
                    />
                  </div>
                  <button type="submit" className="buton-acceso btn-save">
                    Guardar
                  </button>
                </form>
                
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
