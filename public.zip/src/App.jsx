import NavBar from './componentes/navbar/NavBar'
import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './App.css'
import Home from './pages/home/Home';
import Footer from './componentes/footer/Footer';
import Polizas from './pages/polizas/Polizas';

const router = createBrowserRouter([
  {
    path:"/",
    element:<Home />,
  },
  {
    path:"/poliza",
    element:<Polizas />,
  },
])

function App() {
  return (
    <div className="App">
      <NavBar></NavBar>
      <RouterProvider router={router} />   
      <Footer></Footer>
    </div>
  );
}

export default App
